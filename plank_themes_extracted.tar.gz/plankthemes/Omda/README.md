# #OMDA Plank Theme
// By OMAR DAOUD<br>
Installation<br>
extract in<br>
`/usr/share/plank/themes/`
